## LiteOS 设备驱动开发指南

在新的驱动框架下，开发一个设备驱动需要按照如下内容开发

### 填充标准结构体以及其中的数据

- 包含头文件 los_dev.h los_fctl.h los_ioctl_cmd.h
 los_memory.h

- 定义ops结构体 比如static struct los_dev_operations gst_I2cOps = {....} 在该结构体中填入操作的该设备的统一回调接口（open，read、write、ioctl....等等）

- 定义设备加载时的路径，比如有两个i2c控制器，可以定义为static char * pDevPath[ I2C_INSTANCE_NUM_MAX] = 
{
    "/dev/i2c1",
    "/dev/i2c2"
};

- 定义操作设备的私有结构体，比如i2c自定一个static struct los_i2c_prvdata  gst_I2cPrvdata[I2C_INSTANCE_NUM_MAX] ={...}

### 开发open,read,write等等对应的接口

- 首先开发struct los_dev_operations中对应的 open， read，write等等接口，参考结构体的定义。

- 实现module init实际调用函数，例如int los_i2c_module_init(void)中调用LOS_MemAlloc申请struct los_dev
  然后将结构体中的path、privatedata、f_ops成员赋值为上个章节描述的ops、私有数据、path描述等变量。完成后调用los_dev_list_add(&pI2cDev->dev_list);将设备添加到设备管理链表中。

- 完成之后再los_modules_init.c中int los_modules_init()函数中调用module_init(los_i2c_module_init);完成设备驱动的真实注册。

- 目前已经实现了

	/dev/USART2

	/dev/USART3

	/dev/i2c1

	/dev/i2c2

	/dev/gpio/pb7

	/dev/gpio/pb15

	/dev/gpio/pc13

	/dev/SPI1


## LiteOS应用开发指南。

- 基于某个设备进行应用场景开发的时候，可以在一个单独的c文件中，调用open，read、write、ioctl函数对设备进行打开，读写以及ioctl等操作。使用设备前必须先open设备。特殊参数通过ioctl进行设置等等。open设备的路径根据驱动中定义的路径进行匹配，匹配不上则认为设备不存在。

- 比如uart的使用示例
	
		void init_testuart2(void * pvParameters)
		{
	    	int len;
    		//int ret = 0;
    		int fd = -1;
    
			//los_dev_list_init();
			//module_init(los_dev_uarts_init);
    
			//ret = los_dev_uart_init(LOS_STM32L476_UART3, 9600, tb2, 500);
		fd = los_open("/dev/USART3", O_RDWR);
		if (fd < 0)
		{
			while(1);
		}
		while(1)
		{
			//los_dev_uart_write(LOS_STM32L476_UART3, "123\n", 4, 100);
			//len = uart_data_read(tb1, 500, 0);
			//len = los_dev_uart_read(LOS_STM32L476_UART3, tb1, 4, 5000); 
			los_ioctl(fd, IOW_UART_CTL_TIMEOUT, 500);//set read timeout
			len = los_read(fd, tb1, 4); 
			if (len > 0)
				los_write(fd, tb1, len);
			osDelay(10);
		}
		}


## LiteOS的NB程序开发指南

- 在LiteOS中实现了NB数据上传数据的基本框架，在ocean_sample.c中实现了基于NB模块的sample示例。oceancon_sampletask()函数是主要的demo逻辑。NB模块传输数据到华为云平台，必须定义USE_NB_BC95宏（在ocean_sample.c中的头文件包含之后定义）。

- 基本的nb通讯逻辑就是 先初始化ret = ocean_res_init(CON_NB, TRAN_MAX, NB_NEUL_BC95);，然后上报数据ocean_send_data(data, len);，然后读取收到的包处理服务器反馈数据n = ocean_recv_data(test_rbuf, 512);数据的处理根据具体业务来定，比如demo中调用ocean_dev_control(test_rbuf, n);处理服务器的反馈数据。





